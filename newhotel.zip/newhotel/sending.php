<meta http-equiv="refresh" content="5; url=index.php#3">

<div style="margin:0 auto; text-align:center;">
Sending Message
<br>
<img src="ajax-loader.gif">
<br>
Pls........ wait
</div>